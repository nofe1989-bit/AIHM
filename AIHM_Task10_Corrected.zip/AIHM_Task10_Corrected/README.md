# AIHM Tasks 8, 9 & 10 - Corrected Runnable Project
Run from this folder:
python Task10/task10_pipeline_no_comments.py --input Task8 --task9-results Task9/results --output-base Task10/results_corrected
